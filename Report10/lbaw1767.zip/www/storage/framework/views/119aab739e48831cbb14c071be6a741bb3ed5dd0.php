<?php $__env->startSection('content'); ?>

<p>adicionar codigo da home</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base_estatica', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>