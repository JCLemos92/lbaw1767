<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Project;
use Carbon\Carbon;
use DB;

class AuthStaticController extends Controller
{
    /*This controller handles the users static pages*/

    public function index(){
    	return view('authstatic/aut_index');
    }

    public function about(){
    	return view('authstatic/aut_about');
    }
    
    public function faq(){
    	return view('authstatic/aut_faq');
    }

    public function contact(){
    	return view('authstatic/aut_contact');
    }

    private $project;
    public function __construct(Project $project){
        $this->project = $project;

    }

    public function project($index = 0, $search = ''){

        //$itens = $this->project->all();

	if($index < 0)$index = 0;

        //$itens = $this->project->all();
	$items = DB::table('projects')->where([['privacy', 'false'],[ 'proj_title', 'SIMILAR TO', '%' . $search . '%']])->get();

	$itensPub = $items;

	$items = DB::table('projects')->where([['privacy', 'true'],[ 'proj_title', 'SIMILAR TO', '%' . $search . '%']])->get();

	$itensPriv = $items;

	$appliedProj = DB::table('appliedMembers')->where([['user_ID', Auth::id()]])->get();

	$joinedProj = DB::table('projectMembers')->where([['user_ID', Auth::id()]])->get();
            
            return view ('authstatic/aut_projects', compact('itensPub', 'itensPriv', 'appliedProj', 'joinedProj'));
    }

    public function myProject($index = 0, $search = ''){

        //$itens = $this->project->all();

	if($index < 0)$index = 0;

	$projID = DB::table('projectMembers')->where([['user_ID', Auth::id()]])->get();

        //$itens = $this->project->all();
	$itensPub = array();
	$itensPriv = array();
	foreach($projID as $proj){
		$items = DB::table('projects')->where([['id', $proj->project_ID],[ 'proj_title', 'SIMILAR TO', '%' . $search . '%']])->get();
		if(count($items) > 0){
			if($items[0]->privacy == false)
				array_push($itensPub, $items[0]);
			else
				array_push($itensPriv, $items[0]);
		}
            }
            return view ('authstatic/aut_myprojects', compact('itensPub', 'itensPriv'));
    }

    public function publicProject($index = 0){

	if($index < 0)$index = 0;

        //$itens = $this->project->all();
	$items = DB::table('projects')->where([['privacy', 'false']])->get();

	if($index >= count($items))$index = count($items)-1;

	if($index*3 +2<count($items))$itens = array($items[$index*3],$items[$index*3 + 1],$items[$index*3 +2]);
	else if($index*3 +1<count($items))$itens = array($items[$index*3],$items[$index*3 + 1]);
	else if($index*3<count($items))$itens = array($items[$index*3]);
	else $itens = array();

            //$retorno = compact('itens');
            //return ($retorno);
            return view ('authstatic/aut_projects', [compact('itens'), 'privacy'=>'public']);
    }

    public function privateproject($index = 0){

	if($index < 0)$index = 0;

        //$itens = $this->project->all();
	$items = DB::table('projects')->where([['privacy', 'true']])->get();

	if($index >= count($items))$index = count($items)-1;

	if($index*3 +2<count($items))$itens = array($items[$index*3],$items[$index*3 + 1],$items[$index*3 +2]);
	else if($index*3 +1<count($items))$itens = array($items[$index*3],$items[$index*3 + 1]);
	else if($index*3<count($items))$itens = array($items[$index*3]);
	else $itens = array();

            //$retorno = compact('itens');
            //return ($retorno);
            return view ('authstatic/aut_projects', [compact('itens'), 'privacy'=>'private']);
    }



    public function createProject(Request $request){
	$control = explode(":",$request->input('join_validator'));
	$control1 = explode(":",$request->input('cancel_validator'));
	if($request->input('search_validator') == 'search_validator'){
		return $this->project(0, $request->input('search_proj'));
	}
	elseif($control[0] == 'join_validator'){
		//echo $control[1];
		DB::table('appliedMembers')->insert(['project_ID' => $control[1], 'user_ID' => Auth::id(), 'applicationDate' => Carbon::now()->toDateString()]);
		return $this->project(0, '');
	}
	elseif($control1[0] == 'cancel_validator'){
		//echo $control1[1];
		//echo $control[1];
		DB::table('appliedMembers')->where([['project_ID', $control1[1]], ['user_ID', Auth::id()]])->delete();
		return $this->project(0, '');
	}
	else{
		if($request->input('privacy') == 'private'){
        		$projectTable = DB::table('projects')->insertGetId(
    		   		['proj_title' => $request->input('title'), 'proj_description' => $request->input('description'), 'team_size' => $request->input('points'), 'privacy' => 'true']
			);
			DB::table('projectMembers')->insert(['project_ID' => $projectTable, 'user_ID' => Auth::id(), 'role' => 'Coordinator']);
		}
		else{
			$projectTable = DB::table('projects')->insertGetId(
    	   			['proj_title' => $request->input('title'), 'proj_description' => $request->input('description'), 'team_size' => $request->input('points'), 'privacy' => 'false']
			);
			DB::table('projectMembers')->insert(['project_ID' => $projectTable, 'user_ID' => Auth::id(), 'role' => 'Coordinator']);
		}
		//$itens = $this->project->all();
		//return view ('authstatic/aut_projects', [compact('itens'), 'privacy'=>'public']);
		return $this->project(0, '');
	}
    }



    public function viewProject($id){

        //$itens = $this->project->all();
	$projectT = DB::table('projects')->where([['id', $id]])->get();
	$projectUCid = DB::table('projectMembers')->where([['project_ID', $id],['role','Coordinator']])->get();
	$projectUMid = DB::table('projectMembers')->where([['project_ID', $id],['role','Member']])->get();
	$projectUPid = DB::table('projectMembers')->where([['project_ID', $id],['role','Pending']])->get();
	$projectUAid = DB::table('appliedMembers')->where([['project_ID', $id]])->get();
	$projectUAid = DB::table('appliedMembers')->where([['project_ID', $id]])->get();
	$projectUIid = DB::table('invitedMembers')->where([['project_ID', $id]])->get();
	$projectUC = array();
	$projectUM = array();
	$projectUP = array();
	$projectUA = array();
	$projectUI = array();
	$projectUIn = array();
	$userType = "Guest";
	$userID = Auth::id();
	foreach($projectUCid as  $item){
		if($item->user_ID == Auth::id()) $userType = "Coordinator";
		array_push($projectUC, DB::table('users')->where([['id', $item->user_ID]])->get());
	}
	for($i=0; $i < count($projectUMid); $i++){
		if($projectUMid[$i]->user_ID == Auth::id()) $userType = "Member";
		array_push($projectUM, DB::table('users')->where([['id', $projectUMid[$i]->user_ID]])->get());
	}
	for($i=0; $i < count($projectUPid); $i++){
		array_push($projectUP, DB::table('users')->where([['id', $projectUPid[$i]->user_ID]])->get());
	}
	for($i=0; $i < count($projectUAid); $i++){
		array_push($projectUA, DB::table('users')->where([['id', $projectUAid[$i]->user_ID]])->get());
	}
	for($i=0; $i < count($projectUIid); $i++){
		array_push($projectUI, DB::table('users')->where([['id', $projectUIid[$i]->user_id]])->get());
		array_push($projectUIn, DB::table('users')->where([['id', $projectUIid[$i]->inviter_id]])->get());
	}

	$tasksComp = DB::table('tasks')->where([['project_ID', $id], ['status','Completed']])->get();
	$tasksProg = DB::table('tasks')->where([['project_ID', $id], ['status','Progress']])->get();
	$tasksPend = DB::table('tasks')->where([['project_ID', $id], ['status','Pending']])->get();
	$taskProgU = array();
	$taskProgD = array();
	$taskCompU = array();
	$taskCompD = array();
	for($i=0; $i < count($tasksProg); $i++){
		array_push($taskProgD, DB::table('taskInProgress')->where([['task_id', $tasksProg[$i]->task_ID]])->get());
	}
	for($i=0; $i < count($taskProgD); $i++){
		array_push($taskProgU, DB::table('users')->where([['id', $taskProgD[$i][0]->taskworker]])->get());
	}
	for($i=0; $i < count($tasksComp); $i++){
		array_push($taskCompD, DB::table('taskCompleted')->where([['task_id', $tasksComp[$i]->task_ID]])->get());
	}
	for($i=0; $i < count($taskCompD); $i++){
		array_push($taskCompU, DB::table('users')->where([['id', $taskCompD[$i][0]->taskworker]])->get());
	}

        return view ('authstatic/aut_projectPage', compact('projectT', 'projectUCid', 'projectUC', 'projectUM', 'projectUP', 'tasksComp', 'tasksProg', 'tasksPend', 'projectUAid', 'projectUA', 'projectUIid', 'projectUI', 'projectUIn', 'tasksComp', 'tasksProg', 'tasksPend', 'taskProgU', 'taskProgD', 'taskCompU', 'taskCompD', 'userType', 'userID'));

    }



    public function projPostHandler(Request $request,$id){
	//echo $request->input('request_validator');
	$control = explode("_",$request->input('request_validator'));
	$control1 = explode(":",$request->input('response_validator'));
	$control2 = explode("_",$request->input('cancel_validator'));
	if($control[0] == 'accept'){
		DB::table('projectMembers')->insert(['project_ID' => $id, 'user_ID' => $control[1], 'role' => 'Member']);
		DB::table('appliedMembers')->where([['project_ID', $id], ['user_ID', $control[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control[0] == 'decline'){
		DB::table('appliedMembers')->where([['project_ID', $id], ['user_ID', $control[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control1[0] == "demote"){
		DB::table('projectMembers')->where([['project_ID', $id],['user_ID', $control1[1]]])->update(['role' => 'Member']);
		return $this->viewProject($id);
	}
	elseif($control1[0] == "promote"){
		DB::table('projectMembers')->where([['project_ID', $id],['user_ID', $control1[1]]])->update(['role' => 'Coordinator']);
		return $this->viewProject($id);
	}
	elseif($control1[0] == "leave"){
		DB::table('projectMembers')->where([['project_ID', $id],['user_ID', $control1[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control1[0] == "remove"){
		DB::table('projectMembers')->where([['project_ID', $id],['user_ID', $control1[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control1[0] == "delete"){
		DB::table('projectMembers')->where([['project_ID', $id]])->delete();
		DB::table('appliedMembers')->where([['project_ID', $id]])->delete();
		DB::table('bannedMembers')->where([['project_ID', $id]])->delete();
		DB::table('invitedMembers')->where([['project_ID', $id]])->delete();
		DB::table('notification')->where([['project_ID', $id]])->delete();
		$taskIds = DB::table('tasks')->where([['project_ID', $id]])->get();
		foreach($taskIds as $ids){
			DB::table('taskCompleted')->where([['task_ID', $ids->task_ID]])->delete();
			DB::table('taskInProgress')->where([['task_ID', $ids->task_ID]])->delete();
		}
		DB::table('tasks')->where([['project_ID', $id]])->delete();
		$forumIds = DB::table('forumPost')->where([['project_ID', $id]])->get();
		foreach($forumIds as $ids){
			$commentIds = DB::table('comments')->where([['forum_ID', $ids->forum_ID]])->get();
			foreach($commentIds as $ida){
				DB::table('commentDownVote')->where([['comment_ID', $ida->comment_ID]])->delete();
				DB::table('commentUpVote')->where([['comment_ID', $ida->comment_ID]])->delete();
			}
			DB::table('comments')->where([['forum_ID', $ids->forum_ID]])->delete();
		}
		DB::table('forumPost')->where([['project_ID', $id]])->delete();
		DB::table('projects')->where([['id', $id]])->delete();
		return redirect('aut_projects');
	}
	elseif($control1[0] == "takeTask"){
		DB::table('tasks')->where([['project_ID', $id],['task_ID', $control1[1]]])->update(['status' => 'Progress']);
		DB::table('taskInProgress')->insert([['task_id' => $control1[1], 'taskworker' => Auth::id()]]);
		return $this->viewProject($id);
	}
	elseif($control1[0] == "completeTask"){
		DB::table('tasks')->where([['project_ID', $id],['task_ID', $control1[1]]])->update(['status' => 'Completed']);
		DB::table('taskCompleted')->insert([['task_id' => $control1[1], 'taskworker' => Auth::id(), 'completiondate' => Carbon::now()]]);
		DB::table('taskInProgress')->where([['task_id', $control1[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control1[0] == "deleteTask"){
		DB::table('tasks')->where([['project_ID', $id],['task_ID', $control1[1]]])->delete();
		DB::table('taskInProgress')->where([['task_id', $control1[1]]])->delete();
		DB::table('taskCompleted')->where([['task_id', $control1[1]]])->delete();
		return $this->viewProject($id);
	}
	elseif($control2[0] == "cancel"){
		DB::table('invitedMembers')->where([['project_ID', $id],['user_id', $control2[1]]])->delete();
		return $this->viewProject($id);
	}
	else{
		return $this->viewProject($id);
	}
    }



    public function createTask(Request $request, $id){
	if(Carbon::parse($request->input('bday'))->gte(Carbon::now())){
		$projectTable = DB::table('tasks')->insert(['taskOwner' => Auth::id(), 'project_ID' => $id, 'taskName' => $request->input('title'), 'taskDescription' => $request->input('description'), 'priority' => $request->input('priority'), 'dateCreated' => Carbon::now()->toDateString(), 'dateLimit' => $request->input('bday'), 'status' => 'Pending']);
	}
	else{
		$projectTable = DB::table('tasks')->insert(['taskOwner' => Auth::id(), 'project_ID' => $id, 'taskName' => $request->input('title'), 'taskDescription' => $request->input('description'), 'priority' => $request->input('priority'), 'dateCreated' => Carbon::now()->toDateString(), 'status' => 'Pending']);
	}
	return redirect('aut_projects'.$id);
    }

    public function searchContrib(Request $request,$id){
	$control = explode(":",$request->input('response_validator'));
	if($control[0] == "invite"){
		if(count(DB::table('invitedMembers')->where([['project_ID', $id],['user_id', $control[1]]])->get())==0){
			DB::table('invitedMembers')->insert(['project_ID' => $id, 'user_id' =>  $control[1], 'inviter_id' => Auth::id(), 'invitedate' => Carbon::now()->toDateString()]);
		}
		return redirect('aut_projects'.$id);
	}
	$users = DB::table('users')->where([['name', 'SIMILAR TO', '%' . $request->input('fname') . '%'],['last_name', 'SIMILAR TO', '%' . $request->input('lname') . '%']])->get();
	return view('authstatic/aut_projectInvite', compact('users','id'));
    }
}
