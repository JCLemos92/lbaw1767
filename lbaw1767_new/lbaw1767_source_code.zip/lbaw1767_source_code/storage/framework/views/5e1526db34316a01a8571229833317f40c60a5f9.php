<?php $__env->startSection('content'); ?>

<!-- About Information -->
    <section class="testimonials text-center bg-light">

      <div class="container">
        <h2 class="mb-5">About Us</h2>
        <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
            <p>We are dsads adsad sadsads adsadsa dsadsa dsad sa dsadsa daddsdsa dsa dsa dsa ds ad sa dsa d sa d ad sa d sa d sad sa d sad s dsd sd adsad a ds ad sa dsa d sad sa d sad sadsa dsaddsad sadsaddsds adsad ad ad sad   <br /><br /><br /></p>
          </div>
          <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
            <h3 >Our Team </h3> <p><br /></p>
          </div>
        <div class="row">
          <!-- Members -->
          <div class="col-lg-7">
            <div class="testimonial-item mx-auto mb-5 mb-lg-0">
              <img class="img-fluid rounded-circle mb-3" src="img/testimonials-1.jpg" alt="">
              <h5>Margaret E.</h5>
              <p class="font-weight-light mb-0">"This is fantastic! Thanks so much guys!"</p><p></p>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="testimonial-item mx-auto mb-4 mb-lg-0">
              <img class="img-fluid rounded-circle mb-3" src="img/testimonials-2.jpg" alt="">
              <h5>Fred S.</h5>
              <p class="font-weight-light mb-0">"Bootstrap is amazing. I've been using it to create lots of super nice landing pages."</p><p></p>
            </div>
          </div>
          <div class="col-lg-7">
            <div class="testimonial-item mx-auto mb-5 mb-lg-0">
              <img class="img-fluid rounded-circle mb-3" src="img/testimonials-2.jpg" alt="">
              <h5>Fred S.</h5>
              <p class="font-weight-light mb-0">"Bootstrap is amazing. I've been using it to create lots of super nice landing pages."</p><p></p>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="testimonial-item mx-auto mb-5 mb-lg-0">
              <img class="img-fluid rounded-circle mb-3" src="img/testimonials-3.jpg" alt="">
              <h5>Sarah	W.</h5>
              <p class="font-weight-light mb-0">"Thanks so much for making these free resources available to us!"</p><p></p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Call to Action -->
    <section class="call-to-action text-white text-center">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-xl-9 mx-auto">
            <h2 class="mb-4">Ready to get started? Sign up now!</h2>
          </div>
          <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
              <div class="form-row">
                <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                  <button type="submit" class="btn btn-block btn-lg btn-primary" onclick="location.href='<?php echo e(route('create')); ?>'">Sign up for ProPlan!</button>  
                 </div>
              </div>
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.static_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>