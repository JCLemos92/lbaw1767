<!-- Arquivo base para as paginas estáticas -->

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Codigo base para paginas estaticas</h1>

	<?php echo $__env->yieldContent('content'); ?>

<h1>Rodapé</h1>
</body>
</html>