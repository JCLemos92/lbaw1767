<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div id="idresponse" class="modal" align="left">

	<form id="response_form" class="modal-content animate" action="/aut_invite<?php echo e($id); ?>" method="post">
	<?php echo csrf_field(); ?>

	 	<div class="imgcontainer">
		<input id="response_validator" name="response_validator" type="hidden" value=""> </input>
	 		<span onclick="document.getElementById('response_form').submit();" class="close" title="Close Modal">&times;
	 		</span>
    		</div>
	</form>
</div>
<!--/aut_projects<?php echo e($id); ?>invite<?php echo e($item->id); ?>-->
<div class="card-deck">
	<div class="card">
		<div class="card-header"><?php echo e($item->username); ?><tab1>
	<button type="submit" class="btn btn-fail" href="#" onclick="document.getElementById('response_validator').value='invite:<?php echo e($item->id); ?>'; document.getElementById('response_form').submit();" style="width:auto;">INVITE</button>
						</div>
            					<div class="card-body">
            						<h5 class="card-title"><?php echo e($item->username); ?></h5>
            						<p class="card-text"><?php echo e($item->name); ?> <?php echo e($item->last_name); ?></p>
            					</div>
        				</div>
      				</div><br>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br><br>

        <div class="col-xl-0 mx-auto">
            <img  width="100%" height="30" src="img/bg-masthead.jpg" alt="">
    </div>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.auth_static_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>